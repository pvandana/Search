﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlcon"].ToString());
        //100
        //employe
        //wf
        //100---wf
        //web.config-->100
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack==false)
            {
                empidSearch.Visible = false;
                enameSearch.Visible = false;
            }
            
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (DropDownList1.SelectedItem.Text == "EmployeId")
            //{
            //    empidSearch.Visible = true;   
            //}
            //if (DropDownList1.SelectedItem.Text == "Name")
            //{
            //    enameSearch.Visible = true;
            //}


            switch (DropDownList1.SelectedItem.Text)
            {
                case "EmployeId":
                    empidSearch.Visible = true;
                    enameSearch.Visible = false;
                    break;
                case "Name":
                    enameSearch.Visible = true;
                    empidSearch.Visible = false;
                    break;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("GetdataByid", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter p1=new SqlParameter("@pempid",SqlDbType.Int);
            p1.Value=txtSearchEmpid.Text;
            cmd.Parameters.Add(p1);
            SqlDataAdapter da=new SqlDataAdapter(cmd);
            DataSet ds=new DataSet();
            da.Fill(ds,"emp");
            GridView1.DataSource=ds.Tables[0];
            GridView1.DataBind();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
             SqlCommand cmd = new SqlCommand("GetdataByNames", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter p1 = new SqlParameter("@pFirstName", SqlDbType.VarChar);
            p1.Value = txtLastName.Text;
            cmd.Parameters.Add(p1);
            p1 = new SqlParameter("@pLasttName", SqlDbType.VarChar);
            p1.Value = txtFirstName.Text;
            cmd.Parameters.Add(p1);
            SqlDataAdapter da=new SqlDataAdapter(cmd);
            DataSet ds=new DataSet();
            da.Fill(ds,"emp");
            GridView1.DataSource=ds.Tables[0];
            GridView1.DataBind();
        }
    }
}